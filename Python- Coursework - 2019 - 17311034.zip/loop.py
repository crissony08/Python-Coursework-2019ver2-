n = int(input())

for x in range(0,n):
    print(x*x) 
