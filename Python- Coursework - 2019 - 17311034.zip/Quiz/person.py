class Person:
  def __init__(self, word, yourname):
    self.word = word
    self.yourname = yourname
  def printPerson(self):
    print("Hello to " + self.word + self.yourname)
    