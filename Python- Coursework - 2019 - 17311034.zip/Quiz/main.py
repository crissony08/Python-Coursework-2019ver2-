from person import *
from question import *
p1 = Person("Anime", "Cris")
p1.printPerson()
input("Are you ready for the test?")
input("Good!")
input("Start!")

def run_quiz(questions):
     score = 0
     for question in questions:
          answer = input(question.prompt)
          if answer == question.answer:
               score += 1
     print("you got", score, "out of", len(questions))

run_quiz(questions)