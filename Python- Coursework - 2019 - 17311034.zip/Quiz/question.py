class Question:
     def __init__(self, prompt, answer):
          self.prompt = prompt
          self.answer = answer

question_prompts = [
     "1.What anime is made based on a manga?\n(a) Code Geass\n(b) World Trigger\n\n",
     "2.What anime has more that 40 years of history?\n(a) Gundam\n(b) Marcoss \n\n",
     "3.What does the word 'Isekai' meen?\n(a) Another World\n(b) Another Day\n(c) Another City\n(d) None of them\n\n",
     "4.When does No Game No Life S2 coming out ?\n(a) 2020\n(b) 2021\n(c) Never\n\n",
     "5.Which anime are writen by Urobuchi Gen?\n(a) Psycho-Pass\n(b) Fate/Zero\n(c) Both of them\n(d) None of them\n\n",
     "6.How does Oikawa says Iwaizumi Hajime's name?\n(a) Gorila-chan\n(b) Hajime-chan\n(c) Iwa-chan\n\n",
     "7.Did Gintama change magazines to end the series?\n(a) Yes\n(b) No\n\n",
     "8.What does 'Tieria' mean in Tieria Erde's name?\n(a) Earth\n(b) Space\n\n",
     "9.Which pair of characters share the same voice actor?\n(a) Lelouch and Yata\n(b) Miyuki and Suzaku\n(c) Yuya and Lavi\n(d) All of them\n\n"    
]
questions = [
     Question(question_prompts[0], "b"),
     Question(question_prompts[1], "a"),
     Question(question_prompts[2], "a"),
     Question(question_prompts[3], "c"),
     Question(question_prompts[4], "c"),
     Question(question_prompts[5], "c"),
     Question(question_prompts[6], "a"),
     Question(question_prompts[7], "a"),
     Question(question_prompts[8], "d"),
]

def run_quiz(questions):
     score = 0
     for question in questions:
          answer = input(question.prompt)
          if answer == question.answer:
               score += 1
     if score >= 5:
       print("You win with "+str(score)+" points.")
     else:  
       print("You lose with "+str(score)+" points.")