print(*range(1, int(input())+1), sep='')
