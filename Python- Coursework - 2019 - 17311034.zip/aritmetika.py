a = int(input())
b = int(input())

print(a + b)
print(a - b)
print(a * b)
