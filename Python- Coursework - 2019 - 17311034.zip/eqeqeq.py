class Dog(object):
        """A virtual pet dog"""
        def __init__(self, name, hunger = 5, boredom = 0, tiredness = 0):
                print("Bayy!")
                self.name = name
                self.hunger = hunger
                self.boredom = boredom
                self.tiredness = tiredness
        def __str__(self):
                att = "Your doggo friend\n"
                att += "Name: " + self.name + "\n"
                if self.hunger >= 2:
                        print("Your pet is hungry.")
                elif self.boredom >= 2:
                        print("Your pet is bored.")
                elif self.tiredness >= 2:
                        print("Your pet is tired.")
                return att
        def __pass_time(self):
                self.hunger += 1
                self.boredom += 1
                self.tiredness += 1
        def eat(self, food = 5):
                print("Ayyyyyyy!")
                self.hunger -= food
                if self.hunger < 0:
                        self.hunger = 0
                self.__pass_time()
        def play(self, fun = 5):
                print("Ammmmmmm!")
                self.boredom -= fun
                if self.boredom < 0:
                        self.boredom = 0
                self.__pass_time()
        def rest(self, sleep = 5):
                print("...")
                self.tiredness -= sleep
                if self.tiredness < 0:
                        self.tiredness = 0
                self.__pass_time()
#introduce and explain the program to the user
input("Welcome to the pet dog simulation program. You will get the opportunity to look after a dog of choice. Press enter to begin.")
#get the users chosen attributes for their dog
name = input("Please enter a name for your dog: ")
user_dog = Dog(name)
#taking care of the cat loop
choice = None
while choice != "0":
        print("What would you like to do? (Enter 1 to feed the dog, enter 2 to play with the dog, enter 3 to leave the dog to rest or press 0 to exit the program.")
        choice = input(">")
        if choice == "1":
                user_dog.eat
                print(user_dog)
        elif choice == "2":
                user_dog.play
                print(user_dog)
        elif choice == "3":
                user_dog.rest
                print(user_dog)
input("Press enter to exit...") 
